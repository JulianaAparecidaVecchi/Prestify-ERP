package com.prestify.erp.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import com.prestify.erp.dto.categoria.CategoriaRequestDTO;
import com.prestify.erp.dto.categoria.CategoriaResponseDTO;
import com.prestify.erp.enums.TipoCategoria;
import com.prestify.erp.service.CategoriaService;

import java.util.List;

@RestController
@RequestMapping("/api/categorias")
@RequiredArgsConstructor
public class CategoriaController {

    private final CategoriaService categoriaService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public CategoriaResponseDTO cadastrar(
            @Valid @RequestBody CategoriaRequestDTO dados,
            @RequestParam Long organizacaoId) {

        return categoriaService.cadastrar(dados, organizacaoId);
    }

    /**
     * Lista as categorias da organização.
     * O parâmetro "tipo" é opcional: sem ele, devolve todas (serviço e produto).
     */
    @GetMapping
    public List<CategoriaResponseDTO> listar(
            @RequestParam(required = false) TipoCategoria tipo,
            @RequestParam Long organizacaoId) {

        return categoriaService.listar(tipo, organizacaoId);
    }

    @GetMapping("/{id}")
    public CategoriaResponseDTO buscarPorId(
            @PathVariable Long id,
            @RequestParam Long organizacaoId) {

        return categoriaService.buscarPorId(id, organizacaoId);
    }

    @PutMapping("/{id}")
    public CategoriaResponseDTO atualizar(
            @PathVariable Long id,
            @Valid @RequestBody CategoriaRequestDTO dados,
            @RequestParam Long organizacaoId) {

        return categoriaService.atualizar(id, dados, organizacaoId);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void excluir(
            @PathVariable Long id,
            @RequestParam Long organizacaoId) {

        categoriaService.excluir(id, organizacaoId);
    }
}
